[Reading 75 lines from start (total: 75 lines, 0 remaining)]

package br.com.redeakashic.cinematic.client;
import br.com.redeakashic.cinematic.core.SecondaryScreenPolicy;
import br.com.redeakashic.cinematic.render.*;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;
/** Background and texture skin only. Native screen logic, widgets and destructive confirmations remain native. */
public final class SecondaryScreenTheme {
    public static final SecondaryScreenTheme INSTANCE=new SecondaryScreenTheme();
    private static final ResourceLocation BUTTONS=new ResourceLocation("akashiccinematic","textures/gui/widgets_forbidden.png");
    private static final ResourceLocation LIST=new ResourceLocation("akashiccinematic","textures/gui/list_surface.png");\n    private static final ResourceLocation VANILLA_BUTTONS=new ResourceLocation("textures/gui/widgets.png");
    private static final ResourceLocation VANILLA_LIST=new ResourceLocation("textures/gui/options_background.png");
    private static boolean enabled;
    private static BackdropRenderer backdrop;
    private static UiTypography type;
    private static long lastDraw;
    public static int frames;
    public static String lastSection="none";
    private SecondaryScreenTheme(){}
    public static void configure(boolean value){enabled=value;}
    private static boolean supported(GuiScreen screen){
        return enabled&&screen!=null&&SecondaryScreenPolicy.supports(screen.getClass().getName());
    }
    private static boolean current(){
        Minecraft mc=Minecraft.func_71410_x();
        return mc!=null&&supported(mc.field_71462_r);
    }
    @SuppressWarnings("try")
    public static boolean drawBackground(GuiScreen screen,int tint){
        if(!supported(screen)||Boolean.getBoolean("akashic.cinematic.disabled"))return false;
        Minecraft mc=Minecraft.func_71410_x();if(mc==null)return false;
        int w=mc.field_71443_c,h=mc.field_71440_d;if(w<160||h<120)return false;
        try(RawScope scope=new RawScope(w,h)){
            if(backdrop==null)backdrop=new BackdropRenderer();
            if(type==null)type=new UiTypography();
            backdrop.draw(w,h,1);
            NativeVisuals.rect(0,0,w,h,NativeVisuals.INK,.54);
            double x=w*.065,y=h*.072,pw=w*.87,ph=h*.855;
            backdrop.glass(x,y,pw,ph,.72);
            NativeVisuals.rect(x,y,pw,ph,NativeVisuals.INK,.71);
            NativeVisuals.outline(x,y,pw,ph,NativeVisuals.GOLD,.27);
            double unit=Math.max(.65,Math.min(1.75,Math.min(w/1366.0,h/768.0)));
            type.draw("REDE AKASHIC",x+18*unit,y+16*unit,10*unit,pw*.36,false,2*unit,NativeVisuals.GOLD,.92);
            String section=SecondaryScreenPolicy.label(screen.getClass().getName());
            type.draw(section,x+18*unit,y+35*unit,17*unit,pw*.55,true,.8*unit,NativeVisuals.IVORY,.96);
            type.draw("THE END OF FORBIDDEN",x+18*unit,y+ph-28*unit,8*unit,pw*.45,false,1.2*unit,NativeVisuals.MUTED,.74);
            NativeVisuals.rect(x+18*unit,y+58*unit,pw-36*unit,1,NativeVisuals.GOLD,.18);
            frames++;lastSection=section;lastDraw=System.nanoTime();
            return true;
        }catch(RuntimeException|LinkageError ex){
            System.err.println("[AkashicCinematic] Secondary theme background fallback: "+ex);
            release();return false;
        }
    }
    public static ResourceLocation buttonTexture(){return current()?BUTTONS:VANILLA_BUTTONS;}
    public static ResourceLocation listTexture(){return current()?LIST:VANILLA_LIST;}
    @SubscribeEvent public void tick(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END)return;
        Minecraft mc=Minecraft.func_71410_x();
        if(backdrop!=null&&(mc==null||!supported(mc.field_71462_r)))release();
    }
    @SuppressWarnings("try") private static void release(){
        Minecraft mc=Minecraft.func_71410_x();
        try{
            if(mc!=null&&mc.field_71443_c>0&&mc.field_71440_d>0){
                try(RawScope scope=new RawScope(mc.field_71443_c,mc.field_71440_d)){
                    if(backdrop!=null)backdrop.close();if(type!=null)type.close();
                }
            }
        }catch(RuntimeException|LinkageError ex){System.err.println("[AkashicCinematic] Secondary theme cleanup: "+ex);}
        finally{backdrop=null;type=null;}
    }
}

[executed on device: DESKTOP-2QBFI12 (5f899f28-02c2-4be9-864d-825d296d9e15)]